<?php
	
	define('DB_NAME','diario');
	define('DB_HOST', 'localhost');
	define('DB_PASS','');
	define('DB_USER','root');

?>

